//
//  detailViewController.swift
//  kuni.com
//
//  Created by 柳川万結 on 2020/01/24.
//  Copyright © 2020 柳川万結. All rights reserved.e
//

import UIKit

class detailViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var titleTextField: UITextField!
    @IBOutlet var contentTextView: UITextView!
    
    var saveData: UserDefaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        titleTextField.text = saveData.object(forKey: "title") as? String
        contentTextView.text = saveData.object(forKey: "content") as? String
        titleTextField.delegate = self
}
    @IBAction func saveMemo(){
        saveData.set(titleTextField.text, forKey: "title")
        saveData.set(contentTextView.text,forKey: "content")
        let alert: UIAlertController = UIAlertController(title: "タイトル", message: "本文を入れます", preferredStyle: .alert)
        alert.addAction(
            UIAlertAction(
                         title: "OK",
                          style: .default,
                          handler: { action in
                            self.navigationController?.popViewController(animated: true)
            }
        )
    )
        present(alert, animated: true,completion: nil)
        
        
            func textFieldShouldReturn(_ textField: UITextField)-> Bool{
                textField.resignFirstResponder()
                return true


}
    
    }
    
    }

